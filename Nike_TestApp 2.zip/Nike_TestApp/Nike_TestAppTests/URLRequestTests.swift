//
//  URLRequestTests.swift
//  Nike_TestAppTests
//
//  Created by mounika on 3/7/21.
//

import XCTest
@testable import Nike_TestApp

class URLRequestTests: XCTestCase {
    func testJson() throws {
        let expectation = XCTestExpectation(description: "Checking JSON Response")
        ApiManager.manager.getData { (result) in
            switch result {
            case .success(let feed):
                XCTAssertTrue(feed.feed.results.count > 0, "Empty data received")
                expectation.fulfill()
            case .failure(_):
                expectation.isInverted = true
            }
        }
        wait(for: [expectation], timeout: 5.0)
    }
}
