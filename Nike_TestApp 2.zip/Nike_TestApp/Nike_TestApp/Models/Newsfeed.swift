//
//  Newsfeed.swift
//  Nike_TestApp
//
//  Created by mounika on 3/2/21.
//

import Foundation

struct Newsfeed: Codable {
    let feed: Feed
}
