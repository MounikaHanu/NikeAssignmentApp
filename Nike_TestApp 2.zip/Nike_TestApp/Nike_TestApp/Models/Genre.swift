//
//  Genre.swift
//  Nike_TestApp
//
//  Created by mounika on 3/3/21.
//

import Foundation
struct Genre: Codable {
    let genreID, name: String
    let url: String

    enum CodingKeys: String, CodingKey {
        case genreID = "genreId"
        case name, url
    }
}
