//
//  Results.swift
//  Nike_TestApp
//
//  Created by mounika on 3/3/21.
//

import Foundation
struct Results: Codable {
    let artistName, id, releaseDate, name: String
    let kind: String
    let copyright : String
    let artistID: String
    let artistURL: String
    let artworkUrl100: String
    let genres: [Genre]
    let url: String
    let contentAdvisoryRating: String?

    enum CodingKeys: String,CodingKey {
        case artistName, id, releaseDate, name, kind, copyright
        case artistID = "artistId"
        case artistURL = "artistUrl"
        case artworkUrl100, genres, url, contentAdvisoryRating
    }
}
