//
//  FeedListTableViewCell.swift
//  Nike_TestApp
//
//  Created by mounika on 3/4/21.
//

import UIKit

class FeedListTableViewCell: UITableViewCell {
    
    var albumImageView = UIImageView()
    var artistLbl = UILabel()
    var albumName = UILabel()
    var containerView = UIView()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupCell()
        
        configureAlbumImg()
        configureAlbumNme()
        configureArtistName()
        configureContainerView()
        setupConstraints()
        
        accessoryType = .disclosureIndicator
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    

    func setupCell() {
        contentView.addSubview(albumImageView)
        containerView.addSubview(albumName)
        containerView.addSubview(artistLbl)
        contentView.addSubview(containerView)
    }
    
    func setupConstraints() {
        albumImageView.centerYAnchor.constraint(equalTo: self.contentView.centerYAnchor).isActive = true
        albumImageView.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 10).isActive = true
        albumImageView.widthAnchor.constraint(equalToConstant: 70).isActive = true
        albumImageView.heightAnchor.constraint(equalToConstant: 70).isActive = true
        
        containerView.centerYAnchor.constraint(equalTo: self.contentView.centerYAnchor).isActive = true
        containerView.leadingAnchor.constraint(equalTo: self.albumImageView.trailingAnchor, constant: 10).isActive = true
        containerView.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -10).isActive = true
        containerView.heightAnchor.constraint(equalToConstant: 70).isActive = true
        
        artistLbl.topAnchor.constraint(equalTo: self.contentView.topAnchor,constant: 15).isActive = true
        artistLbl.leadingAnchor.constraint(equalTo: self.containerView.leadingAnchor).isActive = true
        artistLbl.trailingAnchor.constraint(equalTo: self.containerView.trailingAnchor).isActive = true
        artistLbl.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        albumName.topAnchor.constraint(equalTo: self.artistLbl.bottomAnchor,constant: 5).isActive = true
        albumName.leadingAnchor.constraint(equalTo: self.containerView.leadingAnchor).isActive = true
        albumName.heightAnchor.constraint(equalToConstant: 30).isActive = true
    }
    
    
    func configureAlbumImg() {
        albumImageView.translatesAutoresizingMaskIntoConstraints = false
        albumImageView.contentMode = .scaleAspectFill
        albumImageView.layer.cornerRadius = 35
        albumImageView.clipsToBounds = true
    }
    
    func configureAlbumNme() {
        albumName.font = UIFont.systemFont(ofSize: 14)
        albumName.numberOfLines = 0
        albumName.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        albumName.translatesAutoresizingMaskIntoConstraints = false
        //return lbl
    }
    func configureArtistName()  {
        artistLbl.font = UIFont.systemFont(ofSize: 16)
        artistLbl.numberOfLines = 0
        artistLbl.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        artistLbl.translatesAutoresizingMaskIntoConstraints = false
        //return lbl
    }
    
    func configureContainerView() {
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.clipsToBounds = true
    }
    
}
