//
//  FeedViewController.swift
//  Nike_TestApp
//
//  Created by mounika on 3/2/21.
//

import UIKit

class FeedViewController: UIViewController {
    
    var results = [Results]()
    let feedTableView = UITableView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTableView()
        setUpNavigation()
        feedTableView.rowHeight = 100
        ApiManager.manager.getData {[weak self] data in
            switch data {
            case .success(let feedData):
                DispatchQueue.main.async {
                    self?.results = feedData.feed.results
                    self?.feedTableView.reloadData()
                }
            case .failure(let error):
                print("error: \(error)")    //show warning alert
            }
        }
    }
    
    private func setupTableView() {
        view.addSubview(feedTableView)
        
        feedTableView.translatesAutoresizingMaskIntoConstraints = false
        feedTableView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        feedTableView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        feedTableView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        feedTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        
        
        
        feedTableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        feedTableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        feedTableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor).isActive = true
        feedTableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor).isActive = true
        feedTableView.register(FeedListTableViewCell.self, forCellReuseIdentifier: "feedsCell")
        feedTableView.dataSource = self
        feedTableView.delegate = self
    }
    func setUpNavigation() {
        navigationItem.title = "Feed"
        self.navigationController?.navigationBar.barTintColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor:#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)]
    }
}


extension FeedViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return results.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "feedsCell", for: indexPath) as? FeedListTableViewCell else {
            return UITableViewCell()
        }
        
        let item = results[indexPath.row]
        cell.artistLbl.text = item.artistName
        cell.albumName.text = item.name
        if let image = CacheManager.manager.fetch(from: item.artworkUrl100), let img = UIImage(data: image) {
            cell.albumImageView.image = img
        } else {
            ApiManager.manager.downloadImage(url: item.artworkUrl100) { (result) in
                DispatchQueue.main.async {
                    switch result {
                    case .success(let received):
                        CacheManager.manager.cahceImage(url: received.1, data: received.0)
                        if let cell = tableView.cellForRow(at: indexPath) as? FeedListTableViewCell, let img = UIImage(data: received.0) {
                            cell.albumImageView.image = img
                        }
                    case .failure(let error):
                        print("Failed to download image: \(error)")
                    }
                }
            }
        }
        
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let destVC = DetailsViewController()
        destVC.resultsItem = results[indexPath.row]
        navigationController?.show(destVC, sender: nil)
    }
}
