//
//  DetailsViewController.swift
//  Nike_TestApp
//
//  Created by mounika on 3/5/21.
//

import UIKit

class DetailsViewController: UIViewController {
    
    var resultsItem: Results?
    
    private var albumImage: UIImageView
    private var copyright: UILabel
    private var name: UILabel
    private var artist: UILabel
    private var genre: UILabel
    private var releaseDt: UILabel
    private var iTunesBtn :UIButton
    
    convenience init() {
        self.init(nibName:nil, bundle:nil)
    }
    
    
    private override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        albumImage = UIImageView(frame: CGRect.zero)
        copyright = UILabel(frame: CGRect.zero)
        name = UILabel(frame: CGRect.zero)
        artist = UILabel(frame: CGRect.zero)
        genre = UILabel(frame: CGRect.zero)
        releaseDt = UILabel(frame: CGRect.zero)
        iTunesBtn = UIButton(frame: CGRect.zero)
        
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Details"
        
        
        
        setup()
        setupConstraints()
        
        if let feedData = resultsItem {
 //populate
                if let imgData = CacheManager.manager.fetch(from: feedData.artworkUrl100), let img = UIImage(data: imgData) {
                    albumImage.image = img
                }
            copyright.text = "Copyright: " + feedData.copyright
            name.text = "Title: " + feedData.name
            artist.text = "Artist: " + feedData.artistName
            let genreText = feedData.genres.map{ $0.name }
            genre.text = "Genre: " + genreText.joined(separator: ", ")
            releaseDt.text = "Released on: " + feedData.releaseDate
            iTunesBtn.addTarget(self, action: #selector(buttonTap), for: .touchUpInside)
            
        }
        
    }
    
    func setup() {
        self.edgesForExtendedLayout = .top
        self.extendedLayoutIncludesOpaqueBars = true
        
        
        view.addSubview(albumImage)
        
        copyright.text = ""
        copyright.lineBreakMode = .byWordWrapping
        copyright.numberOfLines = 0
        copyright.adjustsFontSizeToFitWidth = true
        copyright.minimumScaleFactor = 0.5
        
        name.text = "adfasf"
        artist.text = "eyeyerty"
        genre.text = " qtri al jqoprui aslfj alfjopqij alsfjalsfdj lqsaffj poj lfkjasl jalf "
        releaseDt.text = "30/21/2038"
        
        view.addSubview(copyright)
        view.addSubview(name)
        view.addSubview(artist)
        
        genre.numberOfLines = 0
        view.addSubview(genre)
        view.addSubview(releaseDt)
        view.addSubview(iTunesBtn)
        
        iTunesBtn.setTitle("Itunes", for: .normal)
      
        iTunesBtn.backgroundColor = .blue
        
    }
    
    func setupConstraints() {
        
        albumImage.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
                                        albumImage.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
                                        albumImage.widthAnchor.constraint(equalToConstant: self.view.frame.width - 150),
                                        albumImage.heightAnchor.constraint(equalToConstant: self.view.frame.width - 150),
                                        albumImage.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 10)])
        
        copyright.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
                                        copyright.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 20),
                                        copyright.widthAnchor.constraint(equalToConstant: self.view.frame.width - 80),
                                        copyright.heightAnchor.constraint(equalToConstant: 50),
                                        copyright.topAnchor.constraint(equalTo: albumImage.safeAreaLayoutGuide.bottomAnchor, constant: 10)])
        
        name.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
                                        name.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 20),
                                        name.widthAnchor.constraint(equalToConstant: self.view.frame.width - 80),
                                        name.heightAnchor.constraint(equalToConstant: 30),
                                        name.topAnchor.constraint(equalTo: copyright.safeAreaLayoutGuide.bottomAnchor, constant: 10)])
        
        artist.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
                                        artist.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 20),
                                        artist.widthAnchor.constraint(equalToConstant: self.view.frame.width - 80),
                                        artist.heightAnchor.constraint(equalToConstant: 30),
                                        artist.topAnchor.constraint(equalTo: name.safeAreaLayoutGuide.bottomAnchor, constant: 10)])
        
        genre.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
                                        genre.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 20),
                                        genre.widthAnchor.constraint(equalToConstant: self.view.frame.width - 80),
                                        genre.heightAnchor.constraint(equalToConstant: 30),
                                        genre.topAnchor.constraint(equalTo: artist.safeAreaLayoutGuide.bottomAnchor, constant: 10)])
        
        releaseDt.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
                                        releaseDt.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 20),
                                        releaseDt.widthAnchor.constraint(equalToConstant: self.view.frame.width - 80),
                                        releaseDt.heightAnchor.constraint(equalToConstant: 30),
                                        releaseDt.topAnchor.constraint(equalTo: genre.safeAreaLayoutGuide.bottomAnchor, constant: 10)])
        
        iTunesBtn.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
                                        iTunesBtn.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
                                        iTunesBtn.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 20),
                                        iTunesBtn.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -20),
                                        iTunesBtn.heightAnchor.constraint(equalToConstant: 30)])
                                        //iTunesBtn.widthAnchor.constraint(equalToConstant: self.view.frame.width-100)])
        
    }
    
    @objc func buttonTap() {
        
        if let url = NSURL(string:resultsItem?.url ?? "") {
            UIApplication.shared.open(url as URL,options: [:],completionHandler: nil)
        }
        
    }
    
}
